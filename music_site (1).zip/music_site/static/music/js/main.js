document.addEventListener('DOMContentLoaded', () => {
    const tokenInput = document.querySelector('input[name="csrfmiddlewaretoken"]');
    const csrfToken = tokenInput ? tokenInput.value : '';
    const player = createMiniPlayer();

    document.querySelectorAll('.like-btn').forEach((btn) => {
        btn.addEventListener('click', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            const url = btn.dataset.likeUrl;
            if (!url) return;
            try {
                const resp = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': csrfToken
                    }
                });
                if (!resp.ok) {
                    window.location.href = '/login/?next=' + encodeURIComponent(window.location.pathname);
                    return;
                }
                const data = await resp.json();
                if (data.liked !== undefined) {
                    btn.classList.toggle('liked', data.liked);
                    btn.innerHTML = `<i class="${data.liked ? 'fa-solid' : 'fa-regular'} fa-heart"></i>`;
                }
            } catch (_) {
                btn.classList.add('shake');
                setTimeout(() => btn.classList.remove('shake'), 450);
            }
        });
    });

    document.querySelectorAll('.play-btn').forEach((btn) => {
        btn.addEventListener('click', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            const audio = btn.dataset.audio || btn.closest('[data-audio]')?.dataset.audio;
            if (!audio) return;
            player.load({
                audio,
                title: btn.dataset.title || btn.closest('[data-title]')?.dataset.title || 'نام آهنگ',
                artist: btn.dataset.artist || btn.closest('[data-artist]')?.dataset.artist || 'هنرمند',
                cover: btn.dataset.cover || btn.closest('[data-cover]')?.dataset.cover || ''
            });
            if (btn.dataset.startUrl) {
                fetch(btn.dataset.startUrl, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': csrfToken,
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'device=browser'
                }).catch(() => {});
            }
        });
    });

    document.querySelectorAll('.horizontal-scroll').forEach((scroller) => {
        scroller.addEventListener('wheel', (event) => {
            if (Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
            event.preventDefault();
            scroller.scrollLeft += event.deltaY;
        }, { passive: false });
    });
});

function createMiniPlayer() {
    const shell = document.createElement('div');
    shell.className = 'mini-player';
    shell.innerHTML = `
        <img class="mini-player-cover" alt="">
        <div class="mini-player-meta"><strong></strong><span></span></div>
        <button class="mini-player-toggle" type="button" aria-label="پخش/توقف"><i class="fa-solid fa-pause"></i></button>
        <audio></audio>
    `;
    document.body.appendChild(shell);

    const audio = shell.querySelector('audio');
    const cover = shell.querySelector('.mini-player-cover');
    const title = shell.querySelector('strong');
    const artist = shell.querySelector('span');
    const toggle = shell.querySelector('.mini-player-toggle');

    toggle.addEventListener('click', () => {
        if (audio.paused) audio.play(); else audio.pause();
    });
    audio.addEventListener('play', () => toggle.innerHTML = '<i class="fa-solid fa-pause"></i>');
    audio.addEventListener('pause', () => toggle.innerHTML = '<i class="fa-solid fa-play"></i>');

    return {
        load(track) {
            cover.src = track.cover;
            title.textContent = track.title;
            artist.textContent = track.artist;
            shell.classList.add('visible');
            if (audio.src !== track.audio) audio.src = track.audio;
            audio.play().catch(() => {});
        }
    };
}

function openPlaylistModal() {
    alert('برای افزودن به پلی‌لیست، از صفحه جزئیات یا کتابخانه یک پلی‌لیست را انتخاب کن.');
}
