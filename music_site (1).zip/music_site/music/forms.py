from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

from .models import ArtistProfile, Genre, Music, Playlist, Report

import os


# -------------------------------------------------------------------
# Base Mixin برای استایل‌دهی فرم‌ها
# -------------------------------------------------------------------
class BaseStyledForm:
    """
    Mixin ساده برای اعمال کلاس‌های CSS پایه روی تمام فیلدهای فرم.
    این کلاس فرض می‌کنه که کلاس اصلی، Form یا ModelForm است و
    متد self.fields را دارد.
    """

    base_classes_map = {
        forms.CheckboxInput: "checkbox",
        forms.FileInput: "file-input",
        forms.ClearableFileInput: "file-input",
        forms.Select: "select",
        forms.Textarea: "textarea",
    }

    default_class = "input"

    def _apply_base_classes(self):
        for field in self.fields.values():
            widget = field.widget
            current = widget.attrs.get("class", "").strip()

            # نوع ویجت را با map چک می‌کنیم
            css = self.default_class
            for widget_cls, css_class in self.base_classes_map.items():
                if isinstance(widget, widget_cls):
                    css = css_class
                    break

            widget.attrs["class"] = (current + " " + css).strip()


# -------------------------------------------------------------------
# Music Form
# -------------------------------------------------------------------
class MusicForm(BaseStyledForm, forms.ModelForm):
    MAX_AUDIO_SIZE = 15 * 1024 * 1024

    class Meta:
        model = Music
        fields = ["genre", "audio_file"]
        widgets = {
            "genre": forms.Select(),
            "audio_file": forms.ClearableFileInput(attrs={"accept": "audio/*"}),
        }
        labels = {
            "genre": "ژانر",
            "audio_file": "فایل صوتی",
        }
        help_texts = {
            "audio_file": "حداکثر حجم مجاز ۱۵ مگابایت است. نام آهنگ، خواننده، آلبوم و کاور از خود فایل خوانده می‌شود.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_base_classes()
        self.fields["genre"].queryset = Genre.objects.order_by("name")
        self.fields["genre"].required = True

    def clean_audio_file(self):
        audio = self.cleaned_data.get("audio_file")
        if not audio:
            return audio
        allowed_types = {
            "audio/mpeg", "audio/mp3",
            "audio/wav", "audio/x-wav",
            "audio/flac", "audio/x-flac",
            "audio/mp4", "audio/aac",
            "application/octet-stream",
        }
        if audio.content_type and audio.content_type.lower() not in allowed_types:
            raise forms.ValidationError("فقط فایل‌های صوتی معتبر قابل آپلود هستند.")
        if audio.size > self.MAX_AUDIO_SIZE:
            raise forms.ValidationError("حداکثر حجم فایل صوتی ۱۵ مگابایت است.")
        return audio


# -------------------------------------------------------------------
# Playlist Form
# -------------------------------------------------------------------
class PlaylistForm(BaseStyledForm, forms.ModelForm):
    class Meta:
        model = Playlist
        fields = ["name", "description", "is_public", "cover_image"]
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "نام پلی‌لیست"}),
            "description": forms.Textarea(attrs={"rows": 4, "placeholder": "توضیح کوتاه"}),
            "is_public": forms.CheckboxInput(),
            "cover_image": forms.ClearableFileInput(attrs={"accept": "image/*"}),
        }
        labels = {
            "name": "نام",
            "description": "توضیحات",
            "is_public": "پابلیک",
            "cover_image": "کاور",
        }

    MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5 MB
    ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_base_classes()

    def clean_cover_image(self):
        image = self.cleaned_data.get("cover_image")
        if not image:
            return image

        ext = os.path.splitext(image.name)[1].lower()
        if ext not in self.ALLOWED_IMAGE_EXTENSIONS:
            raise forms.ValidationError("فرمت تصویر معتبر نیست. فرمت‌های مجاز: jpg, jpeg, png, gif, webp")

        if image.size > self.MAX_IMAGE_SIZE:
            raise forms.ValidationError("حداکثر حجم تصویر کاور ۵ مگابایت است.")

        return image


# -------------------------------------------------------------------
# Report Form
# -------------------------------------------------------------------
class ReportForm(BaseStyledForm, forms.ModelForm):
    class Meta:
        model = Report
        fields = ["reason", "description"]
        widgets = {
            "reason": forms.Select(),
            "description": forms.Textarea(attrs={"rows": 4, "placeholder": "توضیحات تکمیلی"}),
        }
        labels = {
            "reason": "علت گزارش",
            "description": "توضیحات",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_base_classes()


# -------------------------------------------------------------------
# Artist Profile Form
# -------------------------------------------------------------------
class ArtistProfileForm(BaseStyledForm, forms.ModelForm):
    class Meta:
        model = ArtistProfile
        fields = ["display_name", "bio", "avatar", "is_public"]
        widgets = {
            "display_name": forms.TextInput(attrs={"placeholder": "نام نمایشی"}),
            "bio": forms.Textarea(attrs={"rows": 4, "placeholder": "بیو کوتاه"}),
            "avatar": forms.ClearableFileInput(attrs={"accept": "image/*"}),
            "is_public": forms.CheckboxInput(),
        }
        labels = {
            "display_name": "نام نمایشی",
            "bio": "بیوگرافی",
            "avatar": "آواتار",
            "is_public": "پروفایل عمومی",
        }

    MAX_AVATAR_SIZE = 5 * 1024 * 1024  # 5 MB
    ALLOWED_AVATAR_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_base_classes()

    def clean_avatar(self):
        avatar = self.cleaned_data.get("avatar")
        if not avatar:
            return avatar

        ext = os.path.splitext(avatar.name)[1].lower()
        if ext not in self.ALLOWED_AVATAR_EXTENSIONS:
            raise forms.ValidationError("فرمت تصویر آواتار معتبر نیست. فرمت‌های مجاز: jpg, jpeg, png, gif, webp")

        if avatar.size > self.MAX_AVATAR_SIZE:
            raise forms.ValidationError("حداکثر حجم تصویر آواتار ۵ مگابایت است.")

        return avatar


# -------------------------------------------------------------------
# Signup Form
# -------------------------------------------------------------------
class SignupForm(BaseStyledForm, forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={"placeholder": "رمز عبور"}),
        label="رمز عبور",
        strip=False,
    )
    password_confirm = forms.CharField(
        widget=forms.PasswordInput(attrs={"placeholder": "تکرار رمز عبور"}),
        label="تکرار رمز عبور",
        strip=False,
    )

    class Meta:
        model = User
        fields = ["username", "email"]
        widgets = {
            "username": forms.TextInput(attrs={"placeholder": "نام کاربری"}),
            "email": forms.EmailInput(attrs={"placeholder": "ایمیل"}),
        }
        labels = {
            "username": "نام کاربری",
            "email": "ایمیل",
        }

    MIN_PASSWORD_LENGTH = 8

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_base_classes()

    # --- ولیدیشن فیلدها ---
    def clean_username(self):
        username = self.cleaned_data.get("username", "").strip()
        if not username:
            raise ValidationError("وارد کردن نام کاربری الزامی است.")

        if User.objects.filter(username__iexact=username).exists():
            raise ValidationError("این نام کاربری قبلاً استفاده شده است.")

        return username

    def clean_email(self):
        email = self.cleaned_data.get("email", "").strip().lower()
        if not email:
            return email  # اگر ایمیل را اجباری نکرده‌ای در مدل

        # اگر خواستی ایمیل یکتا باشد:
        # if User.objects.filter(email__iexact=email).exists():
        #     raise ValidationError("این ایمیل قبلاً ثبت شده است.")
        return email

    def clean_password(self):
        password = self.cleaned_data.get("password")
        if not password:
            raise ValidationError("وارد کردن رمز عبور الزامی است.")

        if len(password) < self.MIN_PASSWORD_LENGTH:
            raise ValidationError(f"رمز عبور باید حداقل {self.MIN_PASSWORD_LENGTH} کاراکتر باشد.")

        # اگر خواستی پیچیدگی بیشتر:
        # if password.isdigit() or password.isalpha():
        #     raise ValidationError("رمز عبور باید ترکیبی از حروف و اعداد باشد.")

        return password

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirm = cleaned_data.get("password_confirm")

        if password and password_confirm and password != password_confirm:
            self.add_error("password_confirm", "رمز عبور و تکرار آن یکسان نیست.")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        # password را از cleaned_data گرفته و هش می‌کنیم
        user.set_password(self.cleaned_data["password"])

        if commit:
            user.save()
        return user


# -------------------------------------------------------------------
# Genre Form
# -------------------------------------------------------------------
class GenreForm(BaseStyledForm, forms.ModelForm):
    class Meta:
        model = Genre
        fields = ["name", "slug", "color"]
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "نام ژانر"}),
            "slug": forms.TextInput(attrs={"placeholder": "slug"}),
            "color": forms.TextInput(attrs={"placeholder": "#111827"}),
        }
        labels = {
            "name": "نام",
            "slug": "اسلاگ",
            "color": "رنگ",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_base_classes()

    def clean_slug(self):
        slug = self.cleaned_data.get("slug", "").strip().lower()
        if not slug:
            raise ValidationError("وارد کردن اسلاگ الزامی است.")
        # اگر در مدل Genre برای slug unique=True گذاشتی،
        # نیازی نیست اینجا چک کنی، ولی برای خطای کاربرپسند می‌تونی:
        # if Genre.objects.filter(slug=slug).exists():
        #     raise ValidationError("این اسلاگ قبلاً استفاده شده است.")
        return slug
