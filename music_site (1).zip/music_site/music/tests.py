from io import BytesIO

from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from mutagen.id3 import APIC, ID3, TALB, TIT2, TPE1

from .models import Genre, Like, Music, Playlist, PlaylistTrack
from .signals import ensure_default_genres


PNG_BYTES = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
    b"\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc``\x00\x00\x00\x04\x00\x01"
    b"\x0b\xe7\x02\x9d\x00\x00\x00\x00IEND\xaeB`\x82"
)


def build_tagged_audio(title="Night Drive", artist="artist", album="Neon"):
    tags = ID3()
    tags.add(TIT2(encoding=3, text=title))
    tags.add(TPE1(encoding=3, text=artist))
    tags.add(TALB(encoding=3, text=album))
    tags.add(APIC(encoding=3, mime="image/png", type=3, desc="cover", data=PNG_BYTES))
    payload = BytesIO()
    tags.save(payload)
    return payload.getvalue()


class MusicPlatformTests(TestCase):
    def setUp(self):
        ensure_default_genres()
        self.genre = Genre.objects.get(slug="happy")
        self.user = User.objects.create_user(username="artist", password="secret123")
        self.other_user = User.objects.create_user(username="listener", password="secret123")
        self.music = Music.objects.create(
            title="Night Drive",
            artist_name="artist",
            genre=self.genre,
            audio_file=SimpleUploadedFile("track.mp3", build_tagged_audio(), content_type="audio/mpeg"),
            uploaded_by=self.user,
            is_public=True,
        )

    def test_home_page_loads_sections(self):
        response = self.client.get(reverse("music:home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Trending")
        self.assertContains(response, "Featured Playlists")
        self.assertContains(response, "Night Drive")

    def test_like_toggle_creates_like_and_redirects_back(self):
        self.client.login(username="listener", password="secret123")
        response = self.client.post(
            reverse("music:toggle_like", args=[self.music.id]),
            {"next": reverse("music:music_list")},
        )
        self.assertRedirects(response, reverse("music:music_list"))
        self.assertTrue(Like.objects.filter(user=self.other_user, music=self.music).exists())

    def test_add_to_playlist_uses_playlist_id(self):
        playlist = Playlist.objects.create(name="Drive", owner=self.other_user, is_public=True)
        self.client.login(username="listener", password="secret123")
        response = self.client.post(
            reverse("music:add_to_playlist", args=[self.music.id]),
            {"playlist_id": playlist.id, "next": reverse("music:library")},
        )
        self.assertRedirects(response, reverse("music:library"))
        self.assertTrue(PlaylistTrack.objects.filter(playlist=playlist, music=self.music).exists())

    def test_upload_reads_metadata_and_cover(self):
        self.client.login(username="artist", password="secret123")
        response = self.client.post(
            reverse("music:add_music"),
            {
                "genre": self.genre.id,
                "is_public": "on",
                "audio_file": SimpleUploadedFile(
                    "sunrise.mp3",
                    build_tagged_audio(title="Sunrise", artist="Skyline", album="Morning"),
                    content_type="audio/mpeg",
                ),
            },
        )
        self.assertRedirects(response, reverse("music:library"))
        uploaded_track = Music.objects.get(title="Sunrise")
        self.assertEqual(uploaded_track.artist_name, "Skyline")
        self.assertEqual(uploaded_track.album, "Morning")
        self.assertTrue(bool(uploaded_track.cover_image))

    def test_private_playlist_not_visible_to_other_users(self):
        playlist = Playlist.objects.create(name="Secret", owner=self.user, is_public=False)
        PlaylistTrack.objects.create(playlist=playlist, music=self.music, added_by=self.user, position=1)
        response = self.client.get(reverse("music:playlist_detail", args=[playlist.id]))
        self.assertEqual(response.status_code, 404)

    def test_owner_can_delete_uploaded_track(self):
        self.client.login(username="artist", password="secret123")
        response = self.client.post(
            reverse("music:delete_music", args=[self.music.id]),
            {"next": reverse("music:library")},
        )
        self.assertRedirects(response, reverse("music:library"))
        self.assertFalse(Music.objects.filter(id=self.music.id).exists())

    def test_autocomplete_returns_tracks_artists_and_playlists(self):
        Playlist.objects.create(name="Night Set", owner=self.user, is_public=True)
        response = self.client.get(reverse("music:search_autocomplete"), {"q": "Night"})
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertTrue(any(item["type"] == "track" for item in payload["results"]))
        self.assertTrue(any(item["type"] == "playlist" for item in payload["results"]))
