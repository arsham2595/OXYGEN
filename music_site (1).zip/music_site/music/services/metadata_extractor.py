from mutagen.mp3 import MP3
from mutagen.id3 import ID3

def extract_metadata(file):
    audio = MP3(file, ID3=ID3)
    data = {}

    data["duration"] = int(audio.info.length)

    if audio.tags:

        if "TIT2" in audio:
            data["title"] = str(audio["TIT2"])

        if "TPE1" in audio:
            data["artist"] = str(audio["TPE1"])

        if "TALB" in audio:
            data["album"] = str(audio["TALB"])

        # cover
        for tag in audio.tags.keys():
            if tag.startswith("APIC"):
                data["cover"] = audio[tag].data
                break

    return data
