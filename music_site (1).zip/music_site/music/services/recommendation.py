# music/services/recommendation.py

from django.db.models import Count
from music.models import Music, ListeningSession, Like, ArtistProfile

def get_recommendations(user, limit=20):
    
    # اگر کاربر جدید است
    if not ListeningSession.objects.filter(user=user).exists():
        return Music.objects.filter(is_public=True).order_by("-created_at")[:limit]

    # ژانرهای محبوب
    genre_stats = (
        ListeningSession.objects.filter(user=user)
        .values("music__genre")
        .annotate(c=Count("id"))
        .order_by("-c")
    )
    top_genres = [g["music__genre"] for g in genre_stats[:3]]

    # هنرمندان محبوب
    artist_stats = (
        ListeningSession.objects.filter(user=user)
        .values("music__uploaded_by")
        .annotate(c=Count("id"))
        .order_by("-c")
    )
    top_artists = [a["music__uploaded_by"] for a in artist_stats[:3]]

    # آهنگ‌هایی که کاربر لایک کرده
    liked = Like.objects.filter(user=user).values_list("music_id", flat=True)

    # پیشنهاد اصلی
    qs = Music.objects.filter(is_public=True).exclude(uploaded_by=user)

    recommendations = qs.filter(
        genre_id__in=top_genres
    ) | qs.filter(
        uploaded_by_id__in=top_artists
    )

    # تنوع اضافه
    final = recommendations.exclude(id__in=liked).order_by("?")[:limit]

    return final
