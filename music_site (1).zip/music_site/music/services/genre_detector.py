# music/services/genre_detector.py

from music.models import Genre

GENRE_KEYWORDS = {
    "hip hop": "hip-hop",
    "hip-hop": "hip-hop",
    "rap": "rap",
    "pop": "pop",
    "rock": "rock",
    "lofi": "lofi",
    "r&b": "rnb",
    "electronic": "electronic",
    "edm": "electronic",
    "metal": "metal",
    "jazz": "jazz",
    "classical": "classical",
}


def detect_genre_from_metadata(metadata: dict):
    if not metadata:
        return None

    raw = (metadata.get("genre") or "").lower().strip()

    if not raw:
        return None

    for key, slug in GENRE_KEYWORDS.items():
        if key in raw:
            try:
                return Genre.objects.get(slug=slug)
            except Genre.DoesNotExist:
                return None

    return None
