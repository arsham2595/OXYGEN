# music/services/trending.py

from django.utils import timezone
from datetime import timedelta
from music.models import Music, ListeningSession, Like
from django.db.models import Count

def get_trending(limit=20):
    now = timezone.now()

    # محدوده‌ی زمانی هوشمند:
    play_window = now - timedelta(hours=24)
    like_window = now - timedelta(hours=72)

    # شمارش پلی‌ها در ۲۴ ساعت اخیر
    play_counts = (
        ListeningSession.objects.filter(started_at__gte=play_window)
        .values("music")
        .annotate(play_score=Count("id"))
    )

    # شمارش لایک‌ها در ۷۲ ساعت اخیر
    like_counts = (
        Like.objects.filter(created_at__gte=like_window)
        .values("music")
        .annotate(like_score=Count("id"))
    )

    # ساخت دیکشنری‌های سریع
    play_map = {item["music"]: item["play_score"] for item in play_counts}
    like_map = {item["music"]: item["like_score"] for item in like_counts}

    musics = Music.objects.filter(is_public=True).only("id", "title", "cover")

    # رتبه‌بندی هوشمند
    def score(m: Music):
        p = play_map.get(m.id, 0)
        l = like_map.get(m.id, 0)
        return (p * 3) + (l * 1.5)  # وزن‌دهی حرفه‌ای

    ranked = sorted(musics, key=score, reverse=True)
    return ranked[:limit]
