from django.contrib import admin

from .models import ArtistProfile, Genre, Like, ListeningSession, Music, Notification, Playlist, PlaylistTrack, Report


@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "color")
    search_fields = ("name", "slug")


@admin.register(ArtistProfile)
class ArtistProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "display_name", "is_public", "followers_count", "created_at")
    search_fields = ("user__username", "display_name")
    list_filter = ("is_public",)


@admin.register(Music)
class MusicAdmin(admin.ModelAdmin):
    list_display = ("title", "display_artist", "genre", "is_public", "uploaded_by", "play_count", "created_at")
    search_fields = ("title", "artist_name", "album", "uploaded_by__username")
    list_filter = ("genre", "is_public", "created_at")


class PlaylistTrackInline(admin.TabularInline):
    model = PlaylistTrack
    extra = 1


@admin.register(Playlist)
class PlaylistAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "is_public", "total_tracks", "updated_at")
    search_fields = ("name", "owner__username")
    list_filter = ("is_public", "created_at")
    inlines = [PlaylistTrackInline]


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display = ("user", "music", "created_at")
    search_fields = ("user__username", "music__title")
    list_filter = ("created_at",)


@admin.register(ListeningSession)
class ListeningSessionAdmin(admin.ModelAdmin):
    list_display = ("user", "music", "started_at", "is_skipped", "device")
    search_fields = ("user__username", "music__title")
    list_filter = ("is_skipped", "started_at")


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "title", "is_read", "created_at")
    search_fields = ("user__username", "title", "message")
    list_filter = ("is_read", "created_at")


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("music", "reporter", "reason", "is_resolved", "created_at")
    search_fields = ("music__title", "reporter__username", "description")
    list_filter = ("reason", "is_resolved", "created_at")
