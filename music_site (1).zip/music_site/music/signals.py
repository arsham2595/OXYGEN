from django.contrib.auth import get_user_model
from django.db.models.signals import post_migrate, post_save
from django.dispatch import receiver

from .models import ArtistProfile, Genre


DEFAULT_GENRES = [
    # Main genres
    ("pop", "پاپ", "#3b82f6"),
    ("rock", "راک", "#22c55e"),
    ("hip-hop", "هیپ‌هاپ", "#14b8a6"),
    ("rap", "رپ", "#ef4444"),
    ("electronic", "الکترونیک", "#6366f1"),
    ("jazz", "جز", "#06b6d4"),
    ("blues", "بلوز", "#1e40af"),
    ("classical", "کلاسیک", "#8b5cf6"),
    ("country", "کانتری", "#f59e0b"),
    ("reggae", "رگه", "#10b981"),
    ("latin", "لاتین", "#f97316"),
    ("k-pop", "کی‌پاپ", "#ec4899"),
    ("rnb", "آر اند بی", "#a855f7"),
    ("metal", "متال", "#374151"),
    ("indie", "ایندی", "#0ea5e9"),
    ("alternative", "آلترناتیو", "#9333ea"),
    ("soundtrack", "موسیقی فیلم", "#64748b"),
    ("instrumental", "بی‌کلام", "#94a3b8"),
    ("ambient", "امبینت", "#334155"),

    # Electronic
    ("house", "هاوس", "#6366f1"),
    ("techno", "تکنو", "#4f46e5"),
    ("trance", "ترنس", "#7c3aed"),
    ("dubstep", "داب‌استپ", "#4338ca"),
    ("lofi", "لوفای", "#818cf8"),

    # Rap
    ("trap", "ترپ", "#dc2626"),
    ("drill", "دریل", "#b91c1c"),
    ("persian-rap", "رپ فارسی", "#ef4444"),
    ("global-rap", "رپ خارجی", "#f97316"),

    # Rock
    ("hard-rock", "هارد راک", "#16a34a"),
    ("punk", "پانک", "#15803d"),
    ("metalcore", "متال‌کور", "#111827"),

    # Regional
    ("persian-pop", "پاپ فارسی", "#0284c7"),
    ("traditional-persian", "سنتی ایرانی", "#7c2d12"),
    ("arabic", "عربی", "#ea580c"),
    ("afrobeat", "آفروبیت", "#059669"),
    ("turkish", "ترکی", "#d97706"),

    # Mood
    ("happy", "شاد", "#fbbf24"),
    ("sad", "غمگین", "#475569"),
    ("nostalgic", "نوستالژیک", "#a855f7"),
    ("romantic", "عاشقانه", "#f43f5e"),
    ("energetic", "انرژیک", "#22d3ee"),
    ("chill", "چیل", "#0ea5e9"),

    # Other
    ("funk", "فانک", "#ec4899"),
    ("other", "سایر", "#64748b"),
]


def ensure_default_genres():
    for slug, name, color in DEFAULT_GENRES:
        Genre.objects.update_or_create(
            slug=slug,
            defaults={
                "name": name,
                "color": color,
            },
        )


@receiver(post_migrate)
def create_defaults(sender, **kwargs):
    if sender.label != "music":
        return

    ensure_default_genres()


@receiver(post_save, sender=get_user_model())
def create_artist_profile(sender, instance, created, **kwargs):
    if created:
        ArtistProfile.objects.get_or_create(user=instance)
