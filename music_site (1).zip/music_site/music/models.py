from django.db import models
from django.contrib.auth.models import User


# ---------------------------------------------------------
# Artist Profile
# ---------------------------------------------------------
class ArtistProfile(models.Model):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE,
        related_name="artist_profile"
    )

    display_name = models.CharField(max_length=255, blank=True)
    bio = models.TextField(blank=True)
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)
    is_public = models.BooleanField(default=True)

    followers = models.ManyToManyField(
        User,
        related_name="following_artists",
        blank=True,
        help_text="کاربرانی که این هنرمند را فالو کرده‌اند",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.display_name or self.user.username

    @property
    def followers_count(self):
        return self.followers.count()

    @property
    def total_tracks(self):
        return self.user.uploaded_music.count()

    @property
    def total_likes(self):
        from django.db.models import Count, Sum
        return (
            self.user.uploaded_music
            .annotate(likes_total=Count("likes"))
            .aggregate(total=Sum("likes_total"))
            .get("total") or 0
        )


# ---------------------------------------------------------
# Genre
# ---------------------------------------------------------
class Genre(models.Model):
    slug = models.SlugField(max_length=50, unique=True, db_index=True)
    name = models.CharField(max_length=100)

    color = models.CharField(
        max_length=20,
        blank=True,
        help_text="کد رنگ برای UI (مثلاً #ff4b5c)",
    )

    def __str__(self):
        return self.name


# ---------------------------------------------------------
# Music
# ---------------------------------------------------------
class Music(models.Model):

    title = models.CharField(max_length=255)
    artist_name = models.CharField(max_length=255, blank=True)

    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="uploaded_music"
    )

    audio_file = models.FileField(upload_to="music/")
    cover = models.ImageField(upload_to="covers/", blank=True, null=True)
    album = models.CharField(max_length=255, blank=True)

    genre = models.ForeignKey(
        Genre,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    duration = models.IntegerField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    is_public = models.BooleanField(default=True)

    play_count = models.PositiveIntegerField(default=0)
    skip_count = models.PositiveIntegerField(default=0)
    share_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.title

    @property
    def display_artist(self):
        return self.artist_name or self.uploaded_by.username

    @property
    def likes_count(self):
        return getattr(self, "likes_total", None) or self.likes.count()

    @property
    def primary_color(self):
        return self.genre.color if self.genre and self.genre.color else "#111827"

    @property
    def cover_image(self):
        return self.cover

    @property
    def duration_seconds(self):
        return self.duration or 0


# ---------------------------------------------------------
# Playlist
# ---------------------------------------------------------
class Playlist(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)

    owner = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name="playlists"
    )

    is_public = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    musics = models.ManyToManyField(
        Music,
        through="PlaylistTrack",
        related_name="in_playlists",
        blank=True,
    )

    cover_image = models.ImageField(
        upload_to="playlist_covers/",
        blank=True, null=True
    )

    def __str__(self):
        return f"{self.name} - {self.owner.username}"

    @property
    def total_tracks(self):
        return self.tracks.count()

    @property
    def total_duration(self):
        return sum(self.tracks.values_list("music__duration_seconds", flat=True))

    @property
    def is_collaborative(self):
        return False


# ---------------------------------------------------------
# Playlist Track
# ---------------------------------------------------------
class PlaylistTrack(models.Model):
    playlist = models.ForeignKey(
        Playlist, on_delete=models.CASCADE,
        related_name="tracks"
    )
    music = models.ForeignKey(
        Music, on_delete=models.CASCADE,
        related_name="playlist_entries"
    )
    added_by = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="added_playlist_tracks"
    )

    position = models.PositiveIntegerField(default=0)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("playlist", "music")
        ordering = ["position", "added_at"]

    def __str__(self):
        return f"{self.playlist.name} → {self.music.title}"


# ---------------------------------------------------------
# Like
# ---------------------------------------------------------
class Like(models.Model):
    user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name="likes"
    )
    music = models.ForeignKey(
        Music, on_delete=models.CASCADE,
        related_name="likes"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "music")
        indexes = [
            models.Index(fields=["music"]),
            models.Index(fields=["user"]),
        ]

    def __str__(self):
        return f"{self.user.username} ❤️ {self.music.title}"


# ---------------------------------------------------------
# Listening Session
# ---------------------------------------------------------
class ListeningSession(models.Model):
    user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name="listening_sessions"
    )
    music = models.ForeignKey(
        Music, on_delete=models.CASCADE,
        related_name="listening_sessions"
    )

    started_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    is_skipped = models.BooleanField(default=False)

    device = models.CharField(max_length=50, blank=True)
    user_agent = models.CharField(max_length=255, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["user"]),
            models.Index(fields=["music"]),
            models.Index(fields=["started_at"]),
        ]

    def __str__(self):
        return f"{self.user.username} ▶ {self.music.title}"


# ---------------------------------------------------------
# Notification
# ---------------------------------------------------------
class Notification(models.Model):
    user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name="notifications"
    )

    title = models.CharField(max_length=255)
    message = models.TextField()

    url = models.URLField(blank=True)

    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user.username} - {self.title}"


# ---------------------------------------------------------
# Report
# ---------------------------------------------------------
class Report(models.Model):
    REPORT_REASON_CHOICES = [
        ("copyright", "نقض کپی‌رایت"),
        ("explicit", "محتوای نامناسب"),
        ("spam", "اسپم"),
        ("other", "سایر"),
    ]

    reporter = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name="reports"
    )
    music = models.ForeignKey(
        Music, on_delete=models.CASCADE,
        related_name="reports"
    )

    reason = models.CharField(max_length=50, choices=REPORT_REASON_CHOICES)
    description = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    is_resolved = models.BooleanField(default=False)

    class Meta:
        indexes = [
            models.Index(fields=["music"]),
            models.Index(fields=["reason"]),
        ]

    def __str__(self):
        return f"Report {self.music.title} by {self.reporter.username}"


class PlaylistSave(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="saved_playlists"
    )

    playlist = models.ForeignKey(
        Playlist,
        on_delete=models.CASCADE,
        related_name="saves"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "playlist")

    def __str__(self):
        return f"{self.user.username} saved {self.playlist.name}"
