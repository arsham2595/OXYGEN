from django.urls import path
from . import views

app_name = "music"

urlpatterns = [
    path('', views.home, name='home'),

    # Auth
    path("signup/", views.signup_view, name="signup"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),

    # Music
    path("music/", views.music_list, name="music_list"),
    path("upload/", views.add_music, name="add_music"),           # تابع اصلی add_music
    path("search/autocomplete/", views.search_autocomplete, name="search_autocomplete"),
    path("<int:pk>/", views.music_detail, name="music_detail"),
    path("<int:pk>/play/", views.play_music, name="play_music"),
    path("<int:pk>/like/", views.toggle_like, name="toggle_like"),
    path("<int:music_id>/listen/", views.start_listening, name="start_listening"),
    path("<int:pk>/delete/", views.delete_music, name="delete_music"),

    # Playlist
    path("playlist/create/", views.create_playlist, name="create_playlist"),
    path("playlist/<int:playlist_id>/", views.playlist_detail, name="playlist_detail"),
    path("playlist/<int:playlist_id>/edit/", views.edit_playlist, name="edit_playlist"),
    path("playlist/<int:playlist_id>/delete/", views.delete_playlist, name="delete_playlist"),
    path("playlist/add/<int:music_id>/", views.add_to_playlist, name="add_to_playlist"),
    path("playlist/<int:playlist_id>/add/<int:music_id>/", views.add_to_playlist, name="add_to_playlist"),
    path("playlist/<int:playlist_id>/remove/<int:music_id>/", views.remove_from_playlist, name="remove_from_playlist"),
    path("playlist/<int:pk>/save/", views.toggle_save_playlist, name="toggle_save_playlist"),
    path("playlist/<int:pk>/visibility/", views.toggle_playlist_visibility, name="toggle_playlist_visibility"),

    # Artist profile
    path("artist/<str:username>/", views.artist_profile_view, name="artist_profile"),  # تغییر نام
    path("artist/<str:username>/follow/", views.toggle_follow_artist, name="toggle_follow_artist"),
    path("artist/profile/edit/", views.edit_artist_profile, name="edit_artist_profile"),

    # Reports
    path("<int:pk>/report/", views.report_music, name="report_music"),

    # Library / liked
    path("library/", views.library, name="library"),
    path("liked/", views.liked_songs_view, name="liked_songs"),

    # Trending & Recommended
    path("trending/", views.trending_view, name="trending"),
    path("recommended/", views.recommended_view, name="recommended"),

    # Genre
    path("genre/<slug:slug>/", views.genre_detail, name="genre_detail"),

    # Genre management (admin)
    path("genres/manage/", views.genre_list_create, name="genre_manage"),
]
