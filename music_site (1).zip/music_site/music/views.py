import logging
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import IntegrityError, transaction
from django.db.models import Count, F, Max, Prefetch, Q, Sum
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.text import slugify
from django.views.decorators.http import require_POST

from .forms import ArtistProfileForm, GenreForm, MusicForm, PlaylistForm, ReportForm, SignupForm
from .metadata import cover_extension, extract_music_metadata
from .models import ArtistProfile, Genre, Like, ListeningSession, Music, Notification, Playlist, PlaylistTrack, Report
from .signals import ensure_default_genres

logger = logging.getLogger(__name__)

TRACK_PREFETCH = Prefetch(
    "tracks",
    queryset=PlaylistTrack.objects.select_related("music", "music__genre", "music__uploaded_by").order_by("position", "added_at"),
)


def _wants_json(request):
    return request.headers.get("x-requested-with") == "XMLHttpRequest" or "application/json" in request.headers.get("accept", "")


def _liked_ids_for_user(user, music_ids=None):
    if not user or not user.is_authenticated:
        return set()
    queryset = Like.objects.filter(user=user)
    if music_ids is not None:
        queryset = queryset.filter(music_id__in=music_ids)
    return set(queryset.values_list("music_id", flat=True))


def _user_playlists(user):
    if not user or not user.is_authenticated:
        return Playlist.objects.none()
    return Playlist.objects.filter(owner=user).order_by("name")


def _create_notification(user, title, message, url=""):
    if user:
        Notification.objects.create(user=user, title=title, message=message, url=url)


def _recommend_tracks(user, limit=8):
    base = Music.objects.filter(is_public=True).select_related("genre", "uploaded_by").annotate(likes_total=Count("likes"))
    if not user or not user.is_authenticated:
        return base.order_by("-likes_total", "-play_count", "-created_at")[:limit]

    liked_genres = list(
        Genre.objects.filter(music__likes__user=user).annotate(score=Count("music__likes")).order_by("-score").values_list("id", flat=True)[:3]
    )
    followed_users = list(
        ArtistProfile.objects.filter(followers=user).values_list("user_id", flat=True)
    )
    listened_tracks = list(
        ListeningSession.objects.filter(user=user).values_list("music_id", flat=True)
    )

    query = Q(uploaded_by_id__in=followed_users) | Q(genre_id__in=liked_genres)
    if listened_tracks:
        query |= Q(id__in=listened_tracks)

    recommendations = base.filter(query).exclude(likes__user=user).distinct().order_by("-likes_total", "-created_at")[:limit]
    if recommendations.count() >= limit:
        return recommendations
    fallback_ids = list(recommendations.values_list("id", flat=True))
    fallback = base.exclude(id__in=fallback_ids).order_by("-created_at")[: max(limit - len(fallback_ids), 0)]
    return list(recommendations) + list(fallback)


def _apply_music_metadata(music, audio_file, should_override=False):
    metadata = extract_music_metadata(audio_file)
    music.title = metadata["title"]
    music.artist_name = metadata["artist"] or music.uploaded_by.username
    music.album = metadata["album"]

    if metadata["cover_bytes"]:
        from django.core.files.base import ContentFile
        filename = f"{slugify(music.title) or 'cover'}{cover_extension(metadata['cover_mime'])}"
        music.cover_image.save(filename, ContentFile(metadata["cover_bytes"]), save=False)


# ---------------------------
# Auth
# ---------------------------

def signup_view(request):
    ensure_default_genres()
    if request.user.is_authenticated:
        return redirect("music:home")

    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            raw_password = form.cleaned_data["password"]
            user = authenticate(username=user.username, password=raw_password)
            if user:
                login(request, user)
            messages.success(request, "حساب کاربری شما با موفقیت ساخته شد.")
            return redirect("music:home")
    else:
        form = SignupForm()
    return render(request, "registration/signup.html", {"form": form})


def login_view(request):
    """ورود کاربر"""
    if request.user.is_authenticated:
        return redirect("music:home")

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, f"خوش آمدید {user.username}!")
            return redirect(request.GET.get("next") or reverse("music:home"))
        else:
            messages.error(request, "نام کاربری یا رمز عبور اشتباه است.")
    return render(request, "registration/login.html")


def logout_view(request):
    """خروج کاربر"""
    logout(request)
    messages.success(request, "با موفقیت خارج شدید.")
    return redirect("music:home")


# ---------------------------
# Home / Search / Library
# ---------------------------

def home(request):
    ensure_default_genres()
    latest_tracks = (
        Music.objects.filter(is_public=True)
        .select_related("genre", "uploaded_by")
        .annotate(likes_total=Count("likes"))
        .order_by("-created_at")[:10]
    )
    trending_tracks = (
        Music.objects.filter(is_public=True)
        .select_related("genre", "uploaded_by")
        .annotate(likes_total=Count("likes"))
        .order_by("-likes_total", "-play_count", "-created_at")[:8]
    )
    featured_playlists = (
        Playlist.objects.filter(is_public=True)
        .select_related("owner")
        .prefetch_related(TRACK_PREFETCH)
        .annotate(tracks_total=Count("tracks", distinct=True))
        .order_by("-updated_at")[:6]
    )
    top_artists = (
        ArtistProfile.objects.filter(is_public=True)
        .select_related("user")
        .annotate(
            track_count=Count("user__uploaded_music", filter=Q(user__uploaded_music__is_public=True), distinct=True),
            followers_total=Count("followers", distinct=True),
        )
        .order_by("-followers_total", "-track_count", "-created_at")[:6]
    )
    popular_users = (
        ArtistProfile.objects.filter(is_public=True)
        .select_related("user")
        .annotate(
            total_likes_count=Count("user__uploaded_music__likes", distinct=True),
            track_count=Count("user__uploaded_music", filter=Q(user__uploaded_music__is_public=True), distinct=True),
        )
        .order_by("-total_likes_count", "-track_count", "-created_at")[:6]
    )

    recommended_tracks = _recommend_tracks(request.user)
    made_for_you = recommended_tracks[:6] if isinstance(recommended_tracks, list) else recommended_tracks[:6]

    context = {
        "page_kind": "home",
        "latest_tracks": latest_tracks,
        "trending_tracks": trending_tracks,
        "featured_playlists": featured_playlists,
        "top_artists": top_artists,
        "popular_users": popular_users,
        "recommended_tracks": recommended_tracks,
        "made_for_you": made_for_you,
        "genres": Genre.objects.order_by("name"),
        "liked_ids": _liked_ids_for_user(request.user),
        "user_playlists": _user_playlists(request.user),
    }
    return render(request, "music/home.html", context)


def music_list(request):
    ensure_default_genres()
    query = request.GET.get("q", "").strip()
    genre_slug = request.GET.get("genre", "").strip()
    mood = request.GET.get("mood", "").strip()
    ordering = request.GET.get("sort", "new")

    musics = Music.objects.filter(is_public=True).select_related("genre", "uploaded_by").annotate(likes_total=Count("likes"))

    if query:
        musics = musics.filter(
            Q(title__icontains=query)
            | Q(artist_name__icontains=query)
            | Q(album__icontains=query)
            | Q(uploaded_by__username__icontains=query)
        )
    if genre_slug:
        musics = musics.filter(genre__slug=genre_slug)
    if mood:
        musics = musics.filter(mood__icontains=mood)

    if ordering == "popular":
        musics = musics.order_by("-likes_total", "-play_count", "-created_at")
    else:
        musics = musics.order_by("-created_at")

    context = {
        "page_kind": "search",
        "search_results": musics[:24],
        "genres": Genre.objects.order_by("name"),
        "liked_ids": _liked_ids_for_user(request.user),
        "user_playlists": _user_playlists(request.user),
        "current_query": query,
        "current_genre": genre_slug,
        "current_mood": mood,
        "current_sort": ordering,
    }
    return render(request, "music/home.html", context)


def search_autocomplete(request):
    # مانند نسخه‌های قبلی
    query = request.GET.get("q", "").strip()
    results = []
    if query:
        tracks = Music.objects.filter(is_public=True).filter(
            Q(title__icontains=query) | Q(artist_name__icontains=query) | Q(album__icontains=query)
        ).select_related("genre")[:5]
        artists = ArtistProfile.objects.filter(is_public=True).filter(
            Q(display_name__icontains=query) | Q(user__username__icontains=query)
        ).select_related("user")[:3]
        playlists = Playlist.objects.filter(is_public=True, name__icontains=query).select_related("owner")[:3]

        for track in tracks:
            results.append({
                "type": "track",
                "title": track.title,
                "subtitle": track.display_artist,
                "url": reverse("music:music_detail", args=[track.pk])
            })
        for artist in artists:
            results.append({
                "type": "artist",
                "title": artist.display_name or artist.user.username,
                "subtitle": "پروفایل هنرمند",
                "url": reverse("music:artist_profile", args=[artist.user.username]),
            })
        for playlist in playlists:
            results.append({
                "type": "playlist",
                "title": playlist.name,
                "subtitle": playlist.owner.username,
                "url": reverse("music:playlist_detail", args=[playlist.id]),
            })
    return JsonResponse({"results": results})


@login_required
def library(request):
    playlists = (
        Playlist.objects.filter(owner=request.user)
        .select_related("owner")
        .prefetch_related(TRACK_PREFETCH)
        .annotate(tracks_total=Count("tracks", distinct=True))
        .order_by("-updated_at")
    )
    liked_tracks = (
        Music.objects.filter(likes__user=request.user)
        .select_related("genre", "uploaded_by")
        .annotate(likes_total=Count("likes"))
        .order_by("-created_at")
    )
    uploads = (
        Music.objects.filter(uploaded_by=request.user)
        .select_related("genre")
        .annotate(likes_total=Count("likes"))
        .order_by("-created_at")
    )
    notifications = request.user.notifications.all()[:6]

    context = {
        "playlists": playlists,
        "liked_tracks": liked_tracks,
        "uploads": uploads,
        "liked_ids": _liked_ids_for_user(request.user),
        "user_playlists": _user_playlists(request.user),
        "notifications": notifications,
    }
    return render(request, "music/library.html", context)


# ---------------------------
# Music CRUD
# ---------------------------
from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _
import mimetypes

# تنظیمات قابل تغییر
ALLOWED_AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".ogg", ".m4a"}
ALLOWED_AUDIO_MIME_PREFIXES = {"audio/", "application/ogg"}
MAX_AUDIO_FILE_SIZE_MB = 20  # مثلا ۲۰ مگابایت

def validate_audio_file(uploaded_file):
    # 1) چک پسوند
    import os
    _, ext = os.path.splitext(uploaded_file.name.lower())
    if ext not in ALLOWED_AUDIO_EXTENSIONS:
        raise ValidationError(
            _("فقط فرمت‌های صوتی مجاز هستند: %(exts)s"),
            params={"exts": ", ".join(sorted(ALLOWED_AUDIO_EXTENSIONS))},
        )

    # 2) چک MIME type (تقریبی، ولی مفید)
    # اگر سرور MIME بده، همین استفاده می‌شه؛ وگرنه با mimetypes حدس می‌زنیم
    mime_type = getattr(uploaded_file, "content_type", None) or mimetypes.guess_type(uploaded_file.name)[0]
    if mime_type is None or not any(mime_type.startswith(p) for p in ALLOWED_AUDIO_MIME_PREFIXES):
        raise ValidationError(_("فایل انتخاب‌شده به‌نظر نمی‌رسد یک فایل صوتی معتبر باشد."))

    # 3) چک حجم
    max_bytes = MAX_AUDIO_FILE_SIZE_MB * 1024 * 1024
    if uploaded_file.size > max_bytes:
        raise ValidationError(
            _("حجم فایل نباید بیشتر از %(max)s مگابایت باشد."),
            params={"max": MAX_AUDIO_FILE_SIZE_MB},
        )
        

@login_required
def add_music(request):
    ensure_default_genres()
    if request.method == "POST":
        form = MusicForm(request.POST, request.FILES)
        if form.is_valid():
            music = form.save(commit=False)
            music.uploaded_by = request.user
            music.is_public = True

            audio_file = request.FILES.get("audio_file")
            if audio_file:
                try:
                    # ✅ اول اعتبارسنجی
                    validate_audio_file(audio_file)

                    # ✅ بعد متادیتا
                    _apply_music_metadata(music, audio_file, should_override=True)
                except ValidationError as ve:
                    # خطاهای ولیدیشن را به فرم اضافه کن
                    form.add_error("audio_file", ve.message)
                    return render(request, "music/add_music.html", {"form": form})
                except Exception as e:
                    logger.warning(f"Metadata extraction failed: {e}")
                    if not music.title:
                        music.title = audio_file.name.rsplit('.', 1)[0].replace('_', ' ').replace('-', ' ')
                    if not music.artist_name:
                        music.artist_name = request.user.username

            music.save()
            messages.success(request, "ترک جدید با موفقیت اضافه شد.")

            follower_ids = list(
                ArtistProfile.objects.filter(user=request.user, followers__isnull=False).values_list("followers", flat=True)
            )
            if follower_ids:
                notifications = [
                    Notification(
                        user_id=uid,
                        title="انتشار ترک جدید",
                        message=f"{music.display_artist} ترک «{music.title}» را منتشر کرد.",
                        url=reverse("music:artist_profile", args=[request.user.username]),
                    )
                    for uid in follower_ids
                ]
                Notification.objects.bulk_create(notifications)

            return redirect("music:library")
    else:
        form = MusicForm(initial={"is_public": True})

    return render(request, "music/add_music.html", {"form": form})



@login_required
def edit_music(request, music_id):
    music = get_object_or_404(Music, id=music_id, uploaded_by=request.user)
    if request.method == "POST":
        form = MusicForm(request.POST, request.FILES, instance=music)
        if form.is_valid():
            music = form.save(commit=False)
            new_audio = request.FILES.get("audio_file")

            if new_audio:
                try:
                    # ✅ اول اعتبارسنجی فایل جدید
                    validate_audio_file(new_audio)

                    # ✅ فقط اگر معتبر بود، فایل‌های قبلی را حذف کن
                    if music.audio_file:
                        music.audio_file.delete(save=False)
                    if music.cover_image:
                        music.cover_image.delete(save=False)

                    try:
                        _apply_music_metadata(music, new_audio, should_override=True)
                    except Exception as e:
                        logger.warning(f"Metadata extraction failed during edit: {e}")

                except ValidationError as ve:
                    # اگر فایل جدید مشکل داشت، فرم را با خطا برگردان
                    form.add_error("audio_file", ve.message)
                    return render(
                        request,
                        "music/add_music.html",
                        {"form": form, "editing": True, "music": music},
                    )

            # به‌روزرسانی title و artist_name از روی فرم (اگر کاربر چیز جدیدی زده باشد)
            if form.cleaned_data.get("title"):
                music.title = form.cleaned_data["title"]
            if form.cleaned_data.get("artist_name"):
                music.artist_name = form.cleaned_data["artist_name"]

            music.save()
            messages.success(request, "اطلاعات ترک به‌روز شد.")
            return redirect("music:library")
    else:
        form = MusicForm(instance=music)

    return render(request, "music/add_music.html", {"form": form, "editing": True, "music": music})



@login_required
def delete_music(request, pk):
    music_id = pk
    music = get_object_or_404(Music, id=music_id, uploaded_by=request.user)
    if request.method == "POST":
        if music.audio_file:
            music.audio_file.delete(save=False)
        if music.cover_image:
            music.cover_image.delete(save=False)
        music.delete()
        messages.success(request, "ترک با موفقیت حذف شد.")
    return redirect(request.POST.get("next") or reverse("music:library"))


def music_detail(request, pk):
    """نمایش جزئیات یک ترک"""
    music = get_object_or_404(Music, id=pk, is_public=True)
    context = {"music": music, "liked_ids": _liked_ids_for_user(request.user, [music.id])}
    return render(request, "music/music_detail.html", context)


@login_required
def play_music(request, pk):
    """ثبت پخش و بازگشت فایل صوتی (ساده)"""
    music = get_object_or_404(Music, id=pk, is_public=True)
    start_listening(request, pk)  # ثبت سشن
    # در اینجا می‌توانید فایل صوتی را مستقیماً برگردانید یا به پخش‌کننده هدایت کنید
    return redirect(music.audio_file.url)


# ---------------------------
# Playlist Views
# ---------------------------

@login_required
def create_playlist(request):
    if request.method == "POST":
        form = PlaylistForm(request.POST, request.FILES)
        if form.is_valid():
            playlist = form.save(commit=False)
            playlist.owner = request.user
            playlist.save()
            messages.success(request, "پلی‌لیست ساخته شد.")
            return redirect("music:playlist_detail", playlist_id=playlist.id)
    else:
        form = PlaylistForm(initial={"is_public": True})
    return render(request, "music/playlist_form.html", {"form": form, "playlist": None})


@login_required
def edit_playlist(request, playlist_id):
    playlist = get_object_or_404(Playlist, id=playlist_id, owner=request.user)
    if request.method == "POST":
        form = PlaylistForm(request.POST, request.FILES, instance=playlist)
        if form.is_valid():
            form.save()
            messages.success(request, "پلی‌لیست ویرایش شد.")
            return redirect("music:playlist_detail", playlist_id=playlist.id)
    else:
        form = PlaylistForm(instance=playlist)
    return render(request, "music/playlist_form.html", {"form": form, "playlist": playlist})


@login_required
def delete_playlist(request, playlist_id):
    playlist = get_object_or_404(Playlist, id=playlist_id, owner=request.user)
    if request.method == "POST":
        if playlist.cover_image:
            playlist.cover_image.delete(save=False)
        playlist.delete()
        messages.success(request, "پلی‌لیست حذف شد.")
    return redirect("music:library")


def _get_playlist_for_view(request, playlist_id):
    playlist = get_object_or_404(
        Playlist.objects.select_related("owner").prefetch_related(TRACK_PREFETCH),
        id=playlist_id,
    )
    if not playlist.is_public and playlist.owner != request.user:
        raise Http404("این پلی‌لیست خصوصی است.")
    return playlist


def playlist_detail(request, playlist_id):
    playlist = _get_playlist_for_view(request, playlist_id)
    tracks = list(playlist.tracks.all())
    music_ids = [track.music_id for track in tracks]
    liked_ids = _liked_ids_for_user(request.user, music_ids)
    total_duration = sum(track.music.duration_seconds for track in tracks)

    context = {
        "playlist": playlist,
        "tracks": tracks,
        "liked_ids": liked_ids,
        "user_playlists": _user_playlists(request.user),
        "can_edit": request.user.is_authenticated and playlist.owner == request.user,
        "total_duration": total_duration,
    }
    return render(request, "music/playlist_detail.html", context)


@login_required
def add_to_playlist(request, music_id, playlist_id=None):
    if request.method != "POST":
        return redirect("music:library")
    music = get_object_or_404(Music, id=music_id)
    playlist_id = playlist_id or request.POST.get("playlist_id")
    playlist = get_object_or_404(Playlist, id=playlist_id, owner=request.user)
    next_url = request.POST.get("next") or reverse("music:playlist_detail", args=[playlist.id])

    try:
        with transaction.atomic():
            max_pos = PlaylistTrack.objects.filter(playlist=playlist).aggregate(m=Max("position"))["m"] or 0
            PlaylistTrack.objects.create(playlist=playlist, music=music, added_by=request.user, position=max_pos + 1)
        messages.success(request, "ترک به پلی‌لیست اضافه شد.")
    except IntegrityError:
        messages.info(request, "این ترک قبلا در پلی‌لیست وجود دارد.")
    return redirect(next_url)


@login_required
def remove_from_playlist(request, playlist_id, music_id):
    playlist = get_object_or_404(Playlist, id=playlist_id, owner=request.user)
    if request.method == "POST":
        PlaylistTrack.objects.filter(playlist=playlist, music_id=music_id).delete()
        messages.success(request, "ترک از پلی‌لیست حذف شد.")
    return redirect(request.POST.get("next") or reverse("music:playlist_detail", args=[playlist.id]))


# ---------------------------
# Likes / Listening
# ---------------------------

@login_required
def toggle_like(request, pk):
    if request.method != "POST":
        return JsonResponse({"error": "invalid_method"}, status=405)

    music = get_object_or_404(Music, id=pk)
    like = Like.objects.filter(user=request.user, music=music).first()
    liked = False
    if like:
        like.delete()
    else:
        Like.objects.create(user=request.user, music=music)
        liked = True

    likes_total = Like.objects.filter(music=music).count()
    if _wants_json(request):
        return JsonResponse({"liked": liked, "likes_total": likes_total, "music_id": music.id})

    messages.success(request, "لایک ترک به‌روز شد.")
    return redirect(request.POST.get("next") or reverse("music:home"))


@login_required
@require_POST
def start_listening(request, music_id):
    music = get_object_or_404(Music, id=music_id, is_public=True)
    device = request.POST.get("device", "browser")
    user_agent = request.META.get("HTTP_USER_AGENT", "")[:255]
    ListeningSession.objects.create(
        user=request.user,
        music=music,
        device=device,
        user_agent=user_agent,
    )
    Music.objects.filter(id=music.id).update(play_count=F("play_count") + 1)
    return JsonResponse({"status": "ok"})


# ---------------------------
# Reports / Profile / Genre
# ---------------------------

@login_required
def report_music(request, pk):
    music = get_object_or_404(Music, id=pk)
    if request.method == "POST":
        form = ReportForm(request.POST)
        if form.is_valid():
            report = form.save(commit=False)
            report.reporter = request.user
            report.music = music
            report.save()
            messages.success(request, "گزارش شما ثبت شد.")
            return redirect("music:music_list")
    else:
        form = ReportForm()
    return render(request, "music/report_music.html", {"form": form, "music": music})


def artist_profile_view(request, username):
    profile = get_object_or_404(ArtistProfile.objects.select_related("user"), user__username=username)
    if not profile.is_public and request.user != profile.user:
        raise Http404("این پروفایل خصوصی است.")

    if request.user.is_authenticated and request.user == profile.user:
        tracks_qs = Music.objects.filter(uploaded_by=profile.user)
    else:
        tracks_qs = Music.objects.filter(uploaded_by=profile.user, is_public=True)

    tracks = tracks_qs.select_related("genre").annotate(likes_total=Count("likes")).order_by("-created_at")

    if request.user.is_authenticated and request.user == profile.user:
        playlists_qs = Playlist.objects.filter(owner=profile.user)
    else:
        playlists_qs = Playlist.objects.filter(owner=profile.user, is_public=True)

    playlists = playlists_qs.prefetch_related(TRACK_PREFETCH)

    can_edit = request.user.is_authenticated and request.user == profile.user
    is_following = request.user.is_authenticated and profile.followers.filter(id=request.user.id).exists()

    context = {
        "profile": profile,
        "tracks": tracks,
        "playlists": playlists,
        "is_following": is_following,
        "can_edit": can_edit,
        "liked_ids": _liked_ids_for_user(request.user),
        "user_playlists": _user_playlists(request.user),
    }
    return render(request, "music/artist_profile.html", context)


@login_required
def edit_artist_profile(request):
    profile, _ = ArtistProfile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        form = ArtistProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "پروفایل هنرمند شما ذخیره شد.")
            return redirect("music:artist_profile", username=request.user.username)
    else:
        form = ArtistProfileForm(instance=profile)
    return render(request, "music/edit_artist_profile.html", {"form": form})


@login_required
def toggle_follow_artist(request, username):
    if request.method != "POST":
        return JsonResponse({"error": "invalid_method"}, status=405)

    profile = get_object_or_404(ArtistProfile.objects.select_related("user"), user__username=username)
    if profile.user == request.user:
        return JsonResponse({"error": "cannot_follow_self"}, status=400)

    following = False
    if profile.followers.filter(id=request.user.id).exists():
        profile.followers.remove(request.user)
    else:
        profile.followers.add(request.user)
        following = True
        _create_notification(
            profile.user,
            "فالوور جدید",
            f"{request.user.username} شما را دنبال کرد.",
            reverse("music:artist_profile", args=[request.user.username]),
        )

    payload = {"following": following, "followers_count": profile.followers.count()}
    if _wants_json(request):
        return JsonResponse(payload)
    return redirect("music:artist_profile", username=username)


@login_required
def genre_list_create(request):
    if not request.user.is_staff:
        raise Http404()

    if request.method == "POST":
        form = GenreForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "ژانر جدید اضافه شد.")
            return redirect("music:genre_manage")
    else:
        form = GenreForm()

    genres = Genre.objects.order_by("name")
    return render(request, "music/genre_manage.html", {"form": form, "genres": genres})


# ---------------------------
# New views for additional endpoints
# ---------------------------

def trending_view(request):
    trending = Music.objects.filter(is_public=True).select_related("genre", "uploaded_by").annotate(likes_total=Count("likes")).order_by("-likes_total", "-play_count", "-created_at")[:20]
    context = {"page_kind": "search", "search_results": trending, "liked_ids": _liked_ids_for_user(request.user), "user_playlists": _user_playlists(request.user)}
    return render(request, "music/home.html", context)


def recommended_view(request):
    recommended = _recommend_tracks(request.user, limit=20)
    context = {"page_kind": "search", "search_results": recommended, "liked_ids": _liked_ids_for_user(request.user), "user_playlists": _user_playlists(request.user)}
    return render(request, "music/home.html", context)


def library_view(request):
    return library(request)  # فراخوانی همان تابع اصلی


def liked_songs_view(request):
    tracks = Music.objects.filter(likes__user=request.user).select_related("genre", "uploaded_by").annotate(likes_total=Count("likes")).order_by("-created_at")
    context = {"page_kind": "search", "search_results": tracks, "liked_ids": _liked_ids_for_user(request.user), "user_playlists": _user_playlists(request.user)}
    return render(request, "music/home.html", context)


def genre_detail(request, slug):
    genre = get_object_or_404(Genre, slug=slug)
    tracks = Music.objects.filter(genre=genre, is_public=True).select_related("genre", "uploaded_by").annotate(likes_total=Count("likes")).order_by("-created_at")
    context = {"page_kind": "search", "search_results": tracks, "genre": genre, "liked_ids": _liked_ids_for_user(request.user), "user_playlists": _user_playlists(request.user)}
    return render(request, "music/home.html", context)


def toggle_save_playlist(request, pk):
    # Stub for future
    return JsonResponse({"saved": True})


def toggle_playlist_visibility(request, pk):
    # Stub for future
    return JsonResponse({"visible": True})
