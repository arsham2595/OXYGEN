from io import BytesIO
from pathlib import Path

from mutagen import File
from mutagen.flac import FLAC, Picture as FLACPicture
from mutagen.id3 import APIC, ID3, ID3NoHeaderError
from mutagen.mp4 import MP4, MP4Cover
from mutagen.mp3 import MP3
from mutagen.oggvorbis import OggVorbis


# ---------------------------------------------------------
# Safe helpers
# ---------------------------------------------------------
def _safe_first(value):
    """
    Mutagen sometimes returns:
    - a list of values
    - a single string
    - a mutagen text frame (with .text attribute)
    """
    if value is None:
        return ""

    # Mutagen ID3 Frame: value.text is list
    if hasattr(value, "text"):
        t = value.text
        if isinstance(t, (list, tuple)):
            return t[0] if t else ""
        return str(t)

    # If list/tuple → return first
    if isinstance(value, (list, tuple)):
        return value[0] if value else ""

    return str(value)


def _guess_mime(cover_bytes):
    """
    Very lightweight MIME detector. Good enough for MP3/MP4/FLAC covers.
    """
    if not cover_bytes:
        return None
    if cover_bytes.startswith(b"\x89PNG"):
        return "image/png"
    if cover_bytes.startswith(b"\xff\xd8"):
        return "image/jpeg"
    return "image/jpeg"


# ---------------------------------------------------------
# Cover Extraction
# ---------------------------------------------------------
def _extract_cover_and_mime(audio):
    """
    Fully supports:
    - MP4/M4A cover ('covr')
    - FLAC pictures
    - MP3 ID3 APIC frames
    - OGG Vorbis METADATA_BLOCK_PICTURE
    """
    if not audio:
        return None, None

    # ----------------------------
    # MP4 / M4A
    # ----------------------------
    if isinstance(audio, MP4):
        covers = audio.tags.get("covr", []) if audio.tags else []
        if covers:
            cover = covers[0]
            if isinstance(cover, MP4Cover):
                mime = (
                    "image/png"
                    if cover.imageformat == MP4Cover.FORMAT_PNG
                    else "image/jpeg"
                )
                return bytes(cover), mime

    # ----------------------------
    # FLAC
    # ----------------------------
    if isinstance(audio, FLAC):
        if audio.pictures:
            picture = audio.pictures[0]
            return picture.data, picture.mime

    # ----------------------------
    # OGG Vorbis (possible METADATA_BLOCK_PICTURE)
    # ----------------------------
    if isinstance(audio, OggVorbis):
        pics = audio.get("metadata_block_picture")
        if pics:
            try:
                import base64
                data = base64.b64decode(pics[0])
                return data, _guess_mime(data)
            except Exception:
                pass

    # ----------------------------
    # MP3 via ID3 APIC
    # ----------------------------
    tags = getattr(audio, "tags", None)
    if tags:
        for frame in tags.values():
            if isinstance(frame, APIC):
                return frame.data, frame.mime

    return None, None


# ---------------------------------------------------------
# Text Tag Extraction
# ---------------------------------------------------------
def _extract_text(audio, keys):
    """
    Extract text across different formats:
    MP3( ID3 ), MP4(©nam, ©ART), FLAC, OGG
    """
    if not audio or not getattr(audio, "tags", None):
        return ""

    tags = audio.tags

    for key in keys:
        value = tags.get(key)
        if not value:
            continue

        # MP4 metadata is always a list
        if isinstance(value, list) and value and isinstance(value[0], (str, bytes)):
            return value[0]

        # Mutagen ID3 frame
        if hasattr(value, "text"):
            return _safe_first(value.text)

        return _safe_first(value)

    return ""


# ---------------------------------------------------------
# Main Extractor
# ---------------------------------------------------------
def extract_music_metadata(uploaded_file):
    uploaded_file.seek(0)
    payload = uploaded_file.read()
    uploaded_file.seek(0)

    # Try reading through Mutagen
    try:
        audio = File(BytesIO(payload))
    except Exception:
        audio = None

    title = ""
    artist = ""
    album = ""
    cover_bytes = None
    cover_mime = None

    if audio:
        title = _extract_text(audio, ["TIT2", "\xa9nam", "title", "TITLE"])
        artist = _extract_text(audio, ["TPE1", "\xa9ART", "artist", "ARTIST"])
        album = _extract_text(audio, ["TALB", "\xa9alb", "album", "ALBUM"])

        cover_bytes, cover_mime = _extract_cover_and_mime(audio)

    # -----------------------------------------------------
    # Fallback: direct ID3 read (MP3)
    # -----------------------------------------------------
    if not title or not artist or not album or not cover_bytes:
        try:
            id3 = ID3(BytesIO(payload))
            title = title or _safe_first(id3.get("TIT2"))
            artist = artist or _safe_first(id3.get("TPE1"))
            album = album or _safe_first(id3.get("TALB"))

            pics = id3.getall("APIC")
            if pics and not cover_bytes:
                cover_bytes = pics[0].data
                cover_mime = pics[0].mime
        except ID3NoHeaderError:
            pass

    # -----------------------------------------------------
    # Fallback: use filename as title
    # -----------------------------------------------------
    if not title:
        title = Path(uploaded_file.name).stem.replace("_", " ").replace("-", " ").strip()

    return {
        "title": title or "Untitled Track",
        "artist": artist,
        "album": album,
        "cover_bytes": cover_bytes,
        "cover_mime": cover_mime,
    }


# ---------------------------------------------------------
# Mime Extension
# ---------------------------------------------------------
def cover_extension(mime):
    mapping = {
        "image/jpeg": ".jpg",
        "image/jpg": ".jpg",
        "image/png": ".png",
        "image/webp": ".webp",
    }
    return mapping.get((mime or "").lower(), ".jpg")
