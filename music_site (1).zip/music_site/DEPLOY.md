# Deploy Guide

## 1) Install dependencies
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 2) Set environment
```bash
cp .env.example .env
```
Then export variables from `.env` in your process manager or shell.

For local development, keep these values disabled:
```env
DJANGO_DEBUG=True
DJANGO_SECURE_COOKIES=False
DJANGO_SECURE_SSL_REDIRECT=False
DJANGO_SECURE_HSTS_SECONDS=0
DJANGO_SECURE_HSTS_INCLUDE_SUBDOMAINS=False
DJANGO_SECURE_HSTS_PRELOAD=False
```

## 3) Collect static and migrate
```bash
python3 manage.py migrate
python3 manage.py collectstatic --noinput
```

## 4) Run with gunicorn
```bash
gunicorn music_site.wsgi:application --bind 0.0.0.0:8000
```

## 5) Reverse proxy
- Point Nginx to Gunicorn
- Serve `/media/` from `media/`
- If SSL is enabled, pass `X-Forwarded-Proto https`

## Notes
- `STATIC_ROOT` is `staticfiles/`
- `MEDIA_ROOT` is `media/`
- Security flags are environment-driven in `music_site/settings.py`
- For production, set `DJANGO_DEBUG=False`
- Only enable `DJANGO_SECURE_SSL_REDIRECT=True`, `DJANGO_SECURE_COOKIES=True`, and HSTS after HTTPS is fully configured in Nginx and `X-Forwarded-Proto` is passed through
